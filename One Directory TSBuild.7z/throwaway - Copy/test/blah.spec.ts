import {Test} from "@/validation/Test";

new Test()
