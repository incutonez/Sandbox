export class TestModel {
  Hi = 1;
}
