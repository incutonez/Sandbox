import {Test} from "@/validation/Test";

export class Test2 extends Test {

}
