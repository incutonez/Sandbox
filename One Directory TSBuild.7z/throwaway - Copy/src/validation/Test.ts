import {TestModel} from "@generated/models/TestModel";

export class Test extends TestModel {
  Blah = true;
}
